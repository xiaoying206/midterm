package hus.oop.statistics;

public class MyNode {
    public double data;
    public MyNode next;
    public MyNode previous;

    public MyNode(double data) {
        /* TODO */
    }

    public MyNode(double data, MyNode next, MyNode previous) {
        /* TODO */
    }
}
