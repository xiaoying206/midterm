package hus.oop.statistics;

public interface MyIterable {
    MyIterator iterator(int start);
}
