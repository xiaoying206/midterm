package hus.oop.vector;

import java.util.List;

public class MyListVector extends MyAbstractVector {
    private List<Double> data;

    /**
     * Khởi tạo mặc định cho vector.
     */
    public MyListVector() {
        /* TODO */
    }

    @Override
    public int size() {
        /* TODO */
    }

    @Override
    public double coordinate(int index) {
        /* TODO */
    }

    @Override
    public double[] coordinates() {
        /* TODO */
    }

    @Override
    public MyListVector insert(double value) {
        /* TODO */
    }

    @Override
    public MyListVector insert(double value, int index) {
        /* TODO */
    }

    @Override
    public MyListVector remove(int index) {
        /* TODO */
    }

    @Override
    public MyListVector extract(int[] indices) {
        /* TODO */
    }

    @Override
    public void set(double value, int index) {
        /* TODO */
    }

    @Override
    public MyListVector add(double value) {
        /* TODO */
    }

    @Override
    public MyListVector add(MyVector another) {
        /* TODO */
    }

    @Override
    public MyListVector addTo(double value) {
        /* TODO */
    }

    @Override
    public MyListVector addTo(MyVector another) {
        /* TODO */
    }

    @Override
    public MyListVector minus(double value) {
        /* TODO */
    }

    @Override
    public MyListVector minus(MyVector another) {
        /* TODO */
    }

    @Override
    public MyListVector minusFrom(double value) {
        /* TODO */
    }

    @Override
    public MyListVector minusFrom(MyVector another) {
        /* TODO */
    }

    @Override
    public double dot(MyVector another) {
        /* TODO */
    }

    @Override
    public MyListVector pow(double power) {
        /* TODO */
    }

    @Override
    public MyListVector scale(double value) {
        /* TODO */
    }

    @Override
    public double norm() {
        /* TODO */
    }
}
