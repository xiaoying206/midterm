package hus.oop.fraction;

public interface MyFractionComparable {
    int compareTo(MyFraction another);
}
