package hus.oop.fraction;

public interface MyFractionComparator {
    int compare(MyFraction left, MyFraction right);
}
