package oop.principles.abstraction;

public abstract class Shape {
    public abstract void draw();
}
