package oop.principles.abstraction;

public class Client {
    public static void main(String[] args) {
        Shape s = new Circle();
        s.draw();
        // Tính trừu tượng: che giấu chi tiết triển khai, chỉ thể hiện hành vi chung.
    }
}
