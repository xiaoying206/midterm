package oop.principles.encapsulation;

public class Client {
    public static void main(String[] args) {
        Student s = new Student("An", 20);
        System.out.println("Tên: " + s.getName());
        System.out.println("Tuổi: " + s.getAge());
        // Tính đóng gói: che giấu dữ liệu thông qua getter/setter thay vì truy cập trực tiếp.
    }
}
