package oop.principles.inheritance;

public class Client {
    public static void main(String[] args) {
        Student s = new Student("An", "123456");
        s.showInfo();
        // Tính kế thừa: lớp Student kế thừa từ Person, dùng lại được thuộc tính và phương thức.
    }
}
