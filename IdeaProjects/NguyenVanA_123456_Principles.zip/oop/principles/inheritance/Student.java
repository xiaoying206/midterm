package oop.principles.inheritance;

public class Student extends Person {
    private String studentId;

    public Student(String name, String studentId) {
        super(name);
        this.studentId = studentId;
    }

    public void showInfo() {
        introduce();
        System.out.println("Mã sinh viên: " + studentId);
    }
}
