package oop.principles.polymorphism;

public class Dog extends Animal {
    @Override
    public void sound() {
        System.out.println("Chó sủa: Gâu gâu");
    }
}
