package oop.principles.polymorphism;

public class Cat extends Animal {
    @Override
    public void sound() {
        System.out.println("Mèo kêu: Meo meo");
    }
}
