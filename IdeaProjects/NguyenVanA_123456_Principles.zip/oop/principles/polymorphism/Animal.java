package oop.principles.polymorphism;

public class Animal {
    public void sound() {
        System.out.println("Animal phát ra âm thanh");
    }
}
